<html>
<head>
<title>�鿴��������</title>
<meta http-equiv="Content-Type" content="text/html;charset=gb2312">
<link href="/res/base.css" rel="stylesheet" type="text/css">
<script src="/res/base.js" language="javascript"></script>
</head>

<body>
<!-- ͷ�� begin -->
<div class="headers">
	<div class="headers_title"><span class="tips">�鿴��������</span></div>
	<div class="headers_oprate"><button onClick="history.back()" class="button">����</button></div>
</div>
<!-- ͷ�� end -->

<div class="space"></div>

<table width="100%" class="edit" style="border:0;">
	<tr>
		<th class="head" width="25%" style="border:2px solid #BADCDC;">��������</th>
		<th class="head" width="25%" style="border:2px solid #BADCDC;">�����¼</th>
		<th class="head" width="25%" style="border:2px solid #BADCDC;">�طü�¼</th>
		<th class="head" width="25%" style="border:2px solid #BADCDC;">��ע����</th>
	</tr>

	<tr>
		<td valign="top" style="border:2px solid #BADCDC; padding:0;">
			<table width="100%" class="edit" style="border:0;">
							<tr>
					<td class="left" style="width:40%">������</td>
					<td class="right" style="width:60%">��ǿ</td>
				</tr>
							<tr>
					<td class="left" style="width:40%">�Ա�</td>
					<td class="right" style="width:60%">��</td>
				</tr>
							<tr>
					<td class="left" style="width:40%">�绰��</td>
					<td class="right" style="width:60%">-</td>
				</tr>
							<tr>
					<td class="left" style="width:40%">QQ��</td>
					<td class="right" style="width:60%"></td>
				</tr>
							<tr>
					<td class="left" style="width:40%">ר�Һţ�</td>
					<td class="right" style="width:60%"></td>
				</tr>
							<tr>
					<td class="left" style="width:40%">�������ͣ�</td>
					<td class="right" style="width:60%">����֢</td>
				</tr>
							<tr>
					<td class="left" style="width:40%">�Ӵ��ˣ�</td>
					<td class="right" style="width:60%"></td>
				</tr>
							<tr>
					<td class="left" style="width:40%">ԤԼʱ�䣺</td>
					<td class="right" style="width:60%">2013-01-03 13:26</td>
				</tr>
							<tr>
					<td class="left" style="width:40%">ý����Դ��</td>
					<td class="right" style="width:60%">�绰</td>
				</tr>
							<tr>
					<td class="left" style="width:40%">��Լ״̬��</td>
					<td class="right" style="width:60%">�ȴ�</td>
				</tr>
							<tr>
					<td class="left" style="width:40%">��Լʱ�䣺</td>
					<td class="right" style="width:60%">δ��Լ</td>
				</tr>
							<tr>
					<td class="left" style="width:40%">�Ӵ�ҽ����</td>
					<td class="right" style="width:60%"></td>
				</tr>
							<tr>
					<td class="left" style="width:40%">�Ӵ����ݣ�</td>
					<td class="right" style="width:60%"></td>
				</tr>
							<tr>
					<td class="left" style="width:40%">����ʱ�䣺</td>
					<td class="right" style="width:60%">2012-12-25 13:26</td>
				</tr>
							<tr>
					<td class="left" style="width:40%">�����ˣ�</td>
					<td class="right" style="width:60%">���֥</td>
				</tr>
							<tr>
					<td class="left" style="width:40%">���ڲ��ţ�</td>
					<td class="right" style="width:60%">�绰�ͷ�</td>
				</tr>
						</table>
		</td>

		<td valign="top" style="border:2px solid #BADCDC; padding:0;">
			<table width="100%" class="edit" style="border:0;">
				<tr>
					<td class="right">�Լ���ѯ����֢��ǿ��֢��2�겡ʷ��</td>
				</tr>
			</table>
		</td>

		<td valign="top" style="border:2px solid #BADCDC; padding:0;">
			<table width="100%" class="edit" style="border:0;">
				<tr>
					<td class="right"><center style='color:gray'>(��������)</center></td>
				</tr>
			</table>
		</td>

		<td valign="top" style="border:2px solid #BADCDC; padding:0;">
			<table width="100%" class="edit" style="border:0;">
				<tr>
					<td class="right"><center style='color:gray'>(��������)</center></td>
				</tr>
			</table>
		</td>
	</tr>
</table>

<div class="button_line">
	<input type="button" class="submit" onClick="history.back()" value="����">
</div>
</body>
</html>